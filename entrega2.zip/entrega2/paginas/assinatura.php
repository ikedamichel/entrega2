<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Michel Ikeda Francisco" />
<link href="..\css\assinatura.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Muli' rel='stylesheet' type='text/css'>
</head>

<body>
<!-- ASSINATURA -->

<table class="tabela">
<tr>
<td>
	<a href="https://www.facebook.com/michel.ikeda" class="facebook" target="_new"><img height="60" width="60" src="..\images\fcb-black.png"></a>
	<a href="https://instagram.com/ikeda27/" class="insta" target="_new"><img height="60" width="60" src="..\images\insta-black.png"></a>
	<a href="https://www.youtube.com/channel/UCFhSnJnckelvH4d7dcKnR4Q/videos" class="yt" target="_new"><img height="60" width="60" src="..\images\yt-black.png"></a>
	<a href="mailto:michel_ikeda@outlook.com?subject=Observei seu site!" class="email" target="_new"><img height="60" width="60" src="..\images\email-black.png"></a>
</td>
<td>
	<div class="fundoAssinatura">
	<div class='assinatura'>
	  <div class='visivel'>
		<p>
		  Faça
		</p>
		<ul>
		  <li>Bem!</li>
		  <li>Melhor!</li>
		  <li>Ikeda!</li>
		</ul>
	  </div>
	</div>
	</div>
</td>
</tr></table>

</body>
</html>