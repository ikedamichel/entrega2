<?php 
//TEMPORARIO, SERÁ LOGIN+SESSION FUTURAMENTE
?>

<!DOCTYPE html>
<html>
<head>
<title>TEMPORARIO, SERÁ LOGIN FUTURAMENTE</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Michel Ikeda Francisco" />
</head>

<frameset rows="*,10%" border="none" >
	<frame src=".\paginas\areaTrabalho.php">
	<frame src=".\paginas\assinatura.php">
</frameset>

</html>